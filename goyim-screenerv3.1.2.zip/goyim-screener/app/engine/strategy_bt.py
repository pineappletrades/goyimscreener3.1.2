"""Strategy backtest: replay the Investing alert every day for ~5 years, then test stop losses.

1. Data (cached): 5 years of daily bars from Public for every stock in the universe + SPY, QQQ, RSP,
   and point-in-time fundamentals from SEC (each quarter only counts from the day after it was filed).
2. Signals: the same rules as the live Investing strategy (MA touch in an uptrend, market cap, FCF,
   revenue growth, EPS growth), evaluated with only the information available on each day.
3. Trades: buy each alert at that day's close, hold up to `hold` trading days (252 = 1 year),
   with or without a stop loss. Every trade is compared with SPY, QQQ and RSP (equal-weight S&P 500)
   over exactly the same days.
4. Stop-loss finder: the same alerts replayed with many stop rules, ranked.
5. Portfolio: equal-sized slots (default 10), $10,000 start, compared with buying and holding each benchmark.

Known limits (shown in the app): the stock list is today's companies (firms that went bust or were
bought out are missing = survivorship bias); fills are at the close / stop price with no fees or slippage.
"""
import math
import os
import pickle
import time
from datetime import date, datetime, timedelta

import numpy as np

from . import paths, store

BENCHES = [("SPY", "S&P 500"), ("QQQ", "Nasdaq 100"), ("RSP", "S&P 500 equal weight")]
HORIZONS = [5, 21, 63, 126, 252]
DATASET_FILE = "strategy_bt_dataset.pkl"
RESULT_FILE = "strategy_bt_result.json"

STOP_GRID = (
    [{"type": "none", "label": "No stop"}]
    + [{"type": "pct", "value": v, "label": f"{v}% below entry"} for v in (3, 5, 7, 10, 12, 15, 20, 25, 30)]
    + [{"type": "atr", "value": v, "label": f"{v}× ATR below entry"} for v in (1.5, 2, 3, 4)]
    + [{"type": "line", "value": v, "label": f"Close {v}% under the touched EMA"} for v in (0, 1, 2, 3, 5, 8)]
    + [{"type": "slow", "value": v, "label": f"Close {v}% under the slow EMA"} for v in (0, 3, 5)]
    + [{"type": "trail", "value": v, "label": f"Trailing {v}% from the high close"} for v in (10, 15, 20, 25, 30)]
)


def _r(x, d=2):
    if x is None:
        return None
    x = float(x)
    return None if math.isnan(x) or math.isinf(x) else round(x, d)


# ======================================================================
# 1. dataset
# ======================================================================
def _ds_path(mode):
    return paths.DATA_DIR / f"strategy_bt_dataset_{mode}.pkl"


def build_dataset(engine, tickers, status, should_stop, log=print, delay=0.1, mode="all"):
    """Fetch bars + point-in-time fundamentals. Saved to data/ so later runs (other settings, stop tests) are instant."""
    from .scanner import Context

    pit_prov = engine.providers_with("pit_fundamentals")
    if not pit_prov:
        raise RuntimeError("Needs SEC EDGAR (point-in-time fundamentals) connected")
    pit_prov = pit_prov[0]
    names = [b for b, _ in BENCHES] + [t for t in tickers if t not in dict(BENCHES)]
    status.update(stage="Downloading prices and filings", total=len(names), done=0)
    bars, pit, fails = {}, {}, []
    prof = {"id": "strategy_bt", "fast": 150, "slow": 200}
    for i, t in enumerate(names):
        if should_stop():
            break
        status.update(done=i, current=t)
        try:
            df = Context(engine, t, prof, {"values": {}, "fetched": set()}).get("bars")
            if df is None or len(df) < 260:
                continue
            idx = df.index.tz_convert(None) if df.index.tz is not None else df.index
            bars[t] = {"d": np.array(idx.normalize().values, dtype="datetime64[D]"),
                       "o": df["open"].values.astype("float32"), "h": df["high"].values.astype("float32"),
                       "l": df["low"].values.astype("float32"), "c": df["close"].values.astype("float32")}
            if t not in dict(BENCHES):
                pit[t] = pit_prov.pit_fundamentals(t)
        except Exception as e:
            fails.append(f"{t}: {e}")
            if len(fails) >= 8 and not bars:
                raise RuntimeError(fails[0])
        if delay:
            time.sleep(delay)
    ds = {"built": datetime.now().isoformat(timespec="seconds"), "bars": bars, "pit": pit, "mode": mode,
          "tickers": [t for t in tickers if t in bars], "fails": fails[:30]}
    path = _ds_path(mode)
    paths.DATA_DIR.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as fh:
        pickle.dump(ds, fh, protocol=pickle.HIGHEST_PROTOCOL)
    return ds


def load_dataset(mode="all", max_age_days=3):
    path = _ds_path(mode)
    if not path.exists():
        return None
    try:
        with open(path, "rb") as fh:
            ds = pickle.load(fh)
    except Exception:
        return None
    age = datetime.now() - datetime.fromisoformat(ds["built"])
    return ds if age <= timedelta(days=max_age_days) else None


# ======================================================================
# 2. signals
# ======================================================================
def _frames(ds):
    """Align every ticker on SPY's trading calendar -> (dates, {field: 2D array [day, ticker]}, tickers)."""
    cal = ds["bars"]["SPY"]["d"]
    tickers = ds["tickers"]
    n, m = len(cal), len(tickers)
    pos = {d: i for i, d in enumerate(cal.tolist())}
    out = {k: np.full((n, m), np.nan, dtype="float64") for k in "ohlc"}
    for j, t in enumerate(tickers):
        b = ds["bars"][t]
        rows = [pos.get(d) for d in b["d"].tolist()]
        keep = [k for k, r in enumerate(rows) if r is not None]
        ri = np.array([rows[k] for k in keep], dtype=int)
        for f in "ohlc":
            out[f][ri, j] = b[f][keep]
    return cal, out, tickers


def _ma(arr, n, kind):
    import pandas as pd

    df = pd.DataFrame(arr)
    if kind == "SMA":
        return df.rolling(n, min_periods=n).mean().values
    return df.ewm(span=n, adjust=False, ignore_na=True).mean().values


def _fund_masks(ds, cal, tickers, close, p):
    """Daily point-in-time masks for the fundamental rules: each filing counts from the next trading day."""
    n, m = close.shape
    fcf = np.full((n, m), np.nan)
    revok = np.zeros((n, m), dtype=bool)
    epsok = np.zeros((n, m), dtype=bool)
    shares = np.full((n, m), np.nan)
    cal_str = np.array([str(d) for d in cal])
    for j, t in enumerate(tickers):
        snaps = ds["pit"].get(t) or []
        hist = []
        for s in snaps:
            hist.append(s)
            start = int(np.searchsorted(cal_str, s["known"], side="right"))   # the day AFTER the filing
            if start >= n:
                continue
            rq = int(p.get("rev_quarters", 1))
            recent = sorted(hist, key=lambda x: x["end"], reverse=True)
            ry = [x.get("rev_yoy") for x in recent[:rq]]
            r_ok = len(ry) == rq and all(v is not None and v > p.get("rev_min_pct", 0) for v in ry)
            ups = [x.get("eps_up") for x in recent[:4]]
            e_ok = bool(ups and ups[0]) and sum(1 for u in ups if u) >= int(p.get("eps_min_quarters", 1))
            revok[start:, j] = r_ok
            epsok[start:, j] = e_ok
            latest = recent[0]
            fcf[start:, j] = latest.get("fcf_ttm") if latest.get("fcf_ttm") is not None else np.nan
            if latest.get("shares"):
                shares[start:, j] = latest["shares"]
    mcap = close * shares
    return fcf, revok, epsok, mcap


def signals(ds, p):
    """Every alert the strategy would have sent. Returns (cal, frames, tickers, alerts, info)."""
    cal, fr, tickers = _frames(ds)
    o, h, l, c = fr["o"], fr["h"], fr["l"], fr["c"]
    kind, fast, slow = p.get("ma_type", "EMA"), int(p.get("fast", 150)), int(p.get("slow", 200))
    F, S = _ma(c, fast, kind), _ma(c, slow, kind)
    tol = 1 + float(p.get("tolerance", 0.5)) / 100
    with np.errstate(invalid="ignore"):
        above = (c > F) & (c > S)
        import pandas as pd
        up = pd.DataFrame(above.astype(float)).shift(1).rolling(20).sum().values >= float(p.get("above_days", 15))
        tf = l <= F * tol
        ts = l <= S * tol
        if p.get("hold", True):
            tf &= c >= F
            ts &= c >= S
    if p.get("new_only", True):
        tf = tf & ~np.vstack([np.zeros((1, tf.shape[1]), bool), tf[:-1]])
        ts = ts & ~np.vstack([np.zeros((1, ts.shape[1]), bool), ts[:-1]])
    lines = p.get("lines", "both")
    if lines == "fast":
        ts[:] = False
    elif lines == "slow":
        tf[:] = False
    seen = np.cumsum(~np.isnan(c), axis=0)
    warm = seen >= max(slow, 60) + 20          # averages settled
    mask = up & (tf | ts) & warm
    fcf, revok, epsok, mcap = _fund_masks(ds, cal, tickers, c, p)
    with np.errstate(invalid="ignore"):
        if p.get("use_fcf", True):
            mask &= fcf > 0
        if p.get("use_rev", True):
            mask &= revok
        if p.get("use_eps", True):
            mask &= epsok
        if p.get("min_cap_b"):
            mask &= mcap >= float(p["min_cap_b"]) * 1e9
    # ATR(14) for ATR stops
    prev_c = np.vstack([np.full((1, c.shape[1]), np.nan), c[:-1]])
    tr = np.nanmax(np.stack([h - l, np.abs(h - prev_c), np.abs(l - prev_c)]), axis=0)
    atr = pd.DataFrame(tr).rolling(14, min_periods=10).mean().values
    days, cols = np.nonzero(mask)
    alerts = []
    for i, j in sorted(zip(days.tolist(), cols.tolist())):
        line = "slow" if ts[i, j] else "fast"
        both = bool(tf[i, j] and ts[i, j])
        alerts.append({"i": i, "j": j, "ticker": tickers[j], "line": "both" if both else line,
                       "entry": float(c[i, j]), "atr": float(atr[i, j]) if not np.isnan(atr[i, j]) else None,
                       "mcap": _r(mcap[i, j] / 1e9, 1) if not np.isnan(mcap[i, j]) else None})
    first = int(np.argmax(warm.any(axis=1))) if warm.any() else 0
    info = {"first_day": str(cal[first]), "last_day": str(cal[-1]), "days": len(cal) - first, "start_index": first}
    return cal, {"o": o, "h": h, "l": l, "c": c, "F": F, "S": S}, tickers, alerts, info


# ======================================================================
# 3. trades
# ======================================================================
def simulate(alert, fr, stop, hold):
    """One trade with one stop rule -> (exit_index, exit_price, reason) ; reason in hold|stop|open."""
    i, j, entry = alert["i"], alert["j"], alert["entry"]
    n = fr["c"].shape[0]
    end = min(n - 1, i + hold)
    if end <= i:
        return i, entry, "open"
    seg = slice(i + 1, end + 1)
    o, l, c = fr["o"][seg, j], fr["l"][seg, j], fr["c"][seg, j]
    t = stop["type"]
    hit, price = None, None
    if t in ("pct", "atr"):
        if t == "pct":
            level = entry * (1 - stop["value"] / 100)
        else:
            if not alert["atr"]:
                level = None
            else:
                level = entry - stop["value"] * alert["atr"]
        if level is not None:
            idx = np.nonzero(l <= level)[0]
            if len(idx):
                k = idx[0]
                hit = i + 1 + k
                op = o[k]
                price = min(op, level) if not np.isnan(op) else level      # gap down = fill at the open
    elif t == "line":
        ma = fr["S"][seg, j] if alert["line"] in ("slow", "both") else fr["F"][seg, j]
        idx = np.nonzero(c < ma * (1 - stop["value"] / 100))[0]
        if len(idx):
            hit = i + 1 + idx[0]
            price = c[idx[0]]
    elif t == "slow":
        idx = np.nonzero(c < fr["S"][seg, j] * (1 - stop["value"] / 100))[0]
        if len(idx):
            hit = i + 1 + idx[0]
            price = c[idx[0]]
    elif t == "trail":
        hw = np.maximum.accumulate(np.where(np.isnan(c), -np.inf, np.maximum(c, entry)))
        idx = np.nonzero(c <= hw * (1 - stop["value"] / 100))[0]
        if len(idx):
            hit = i + 1 + idx[0]
            price = c[idx[0]]
    if hit is not None and not np.isnan(price):
        return int(hit), float(price), "stop"
    last = end
    while last > i and np.isnan(fr["c"][last, j]):
        last -= 1
    return int(last), float(fr["c"][last, j]), ("hold" if i + hold <= n - 1 else "open")


def _bench_ret(bench_c, i, k):
    a, b = bench_c[i], bench_c[k]
    return (b / a - 1) * 100 if a and not np.isnan(a) and not np.isnan(b) else None


def trade_stats(trades):
    done = [t for t in trades if t["reason"] != "open"]
    rets = [t["ret"] for t in done]
    if not rets:
        return {"n": 0, "open": len(trades)}
    wins, losses = [r for r in rets if r > 0], [r for r in rets if r <= 0]
    srt = sorted(rets)
    med = srt[len(srt) // 2] if len(srt) % 2 else (srt[len(srt) // 2 - 1] + srt[len(srt) // 2]) / 2
    out = {"n": len(done), "open": len(trades) - len(done), "win": _r(100 * len(wins) / len(rets), 1),
           "avg": _r(np.mean(rets)), "median": _r(med), "avg_win": _r(np.mean(wins)) if wins else None,
           "avg_loss": _r(np.mean(losses)) if losses else None,
           "pf": _r(sum(wins) / abs(sum(losses)), 2) if losses and sum(losses) != 0 else None,
           "best": _r(srt[-1]), "worst": _r(srt[0]), "days": _r(np.mean([t["days"] for t in done]), 0),
           "stopped": _r(100 * sum(1 for t in done if t["reason"] == "stop") / len(done), 1)}
    for b, _ in BENCHES:
        ex = [t["ret"] - t["bench"][b] for t in done if t["bench"].get(b) is not None]
        out[f"vs_{b}"] = _r(np.mean(ex)) if ex else None
        out[f"beat_{b}"] = _r(100 * sum(1 for x in ex if x > 0) / len(ex), 1) if ex else None
    return out


def run_trades(alerts, fr, bench, stop, hold):
    trades = []
    for a in alerts:
        k, px, reason = simulate(a, fr, stop, hold)
        ret = (px / a["entry"] - 1) * 100
        trades.append({"a": a, "exit_i": k, "exit": px, "reason": reason, "ret": ret, "days": k - a["i"],
                       "bench": {b: _bench_ret(bench[b], a["i"], k) for b in bench}})
    return trades


# ======================================================================
# 4. portfolio
# ======================================================================
def portfolio(trades, fr, start_i, n_days, slots=10, capital=10_000.0):
    """Equal slots: each new alert gets 1/slots of current equity if a slot is free; else it's skipped."""
    c = fr["c"]
    by_entry = {}
    for t in trades:
        by_entry.setdefault(t["a"]["i"], []).append(t)
    cash, open_pos, equity = capital, [], []
    taken = skipped = 0
    peak, maxdd = capital, 0.0
    invested_days = 0
    for d in range(start_i, n_days):
        # exits at today's prices
        still = []
        for pz in open_pos:
            if pz["t"]["exit_i"] <= d:
                cash += pz["sh"] * pz["t"]["exit"]
            else:
                still.append(pz)
        open_pos = still
        val = cash
        for pz in open_pos:
            px = c[d, pz["j"]]
            pz["last"] = px if not np.isnan(px) else pz["last"]
            val += pz["sh"] * pz["last"]
        # new entries at today's close
        for t in sorted(by_entry.get(d, []), key=lambda x: -(x["a"]["mcap"] or 0)):
            if len(open_pos) >= slots or any(pz["j"] == t["a"]["j"] for pz in open_pos):
                skipped += 1
                continue
            alloc = min(cash, val / slots)
            if alloc <= 0:
                skipped += 1
                continue
            sh = alloc / t["a"]["entry"]
            cash -= alloc
            open_pos.append({"t": t, "j": t["a"]["j"], "sh": sh, "last": t["a"]["entry"]})
            taken += 1
        if open_pos:
            invested_days += 1
        peak = max(peak, val)
        maxdd = min(maxdd, (val / peak - 1) * 100)
        equity.append(val)
    years = max(1e-9, (n_days - start_i) / 252)
    total = (equity[-1] / capital - 1) * 100 if equity else 0
    cagr = ((equity[-1] / capital) ** (1 / years) - 1) * 100 if equity and equity[-1] > 0 else None
    return {"equity": equity, "total": _r(total), "cagr": _r(cagr), "maxdd": _r(maxdd), "taken": taken,
            "skipped": skipped, "exposure": _r(100 * invested_days / max(1, n_days - start_i), 1),
            "calmar": _r(cagr / abs(maxdd), 2) if cagr is not None and maxdd < 0 else None, "final": _r(equity[-1] if equity else capital, 0)}


def buy_hold(series, start_i, capital=10_000.0):
    s = series[start_i:]
    s = s[~np.isnan(s)]
    if not len(s):
        return None
    eq = capital * s / s[0]
    peak = np.maximum.accumulate(eq)
    years = max(1e-9, len(s) / 252)
    return {"equity": eq.tolist(), "total": _r((eq[-1] / capital - 1) * 100), "maxdd": _r(((eq / peak) - 1).min() * 100),
            "cagr": _r(((eq[-1] / capital) ** (1 / years) - 1) * 100), "final": _r(eq[-1], 0)}


# ======================================================================
# 5. everything together
# ======================================================================
def run(ds, p, status=None):
    st = status if status is not None else {}
    st.update(stage="Finding every past alert")
    cal, fr, tickers, alerts, info = signals(ds, p)
    bench = {}
    for b, _ in BENCHES:
        if b in ds["bars"]:
            bb = ds["bars"][b]
            pos = {d: k for k, d in enumerate(bb["d"].tolist())}
            bench[b] = np.array([bb["c"][pos[d]] if d in pos else np.nan for d in cal.tolist()], dtype="float64")
    hold = int(p.get("hold_days", 252))
    slots = int(p.get("slots", 10))
    start_i, n = info["start_index"], len(cal)

    # horizons without a stop
    hz = {}
    for hd in HORIZONS:
        rets, ex = [], {b: [] for b in bench}
        for a in alerts:
            k = a["i"] + hd
            if k >= n or np.isnan(fr["c"][k, a["j"]]):
                continue
            r = (fr["c"][k, a["j"]] / a["entry"] - 1) * 100
            rets.append(r)
            for b in bench:
                br = _bench_ret(bench[b], a["i"], k)
                if br is not None:
                    ex[b].append(r - br)
        hz[str(hd)] = {"n": len(rets), "win": _r(100 * np.mean([r > 0 for r in rets]), 1) if rets else None,
                       "avg": _r(np.mean(rets)) if rets else None, "median": _r(np.median(rets)) if rets else None,
                       **{f"vs_{b}": _r(np.mean(v)) if v else None for b, v in ex.items()},
                       **{f"beat_{b}": _r(100 * np.mean([x > 0 for x in v]), 1) if v else None for b, v in ex.items()}}

    # stop-loss finder
    st.update(stage="Testing stop losses", total=len(STOP_GRID), done=0)
    finder, main = [], None
    chosen = p.get("stop") or {"type": "none"}
    for k, stop in enumerate(STOP_GRID):
        st.update(done=k, current=stop["label"])
        trades = run_trades(alerts, fr, bench, stop, hold)
        ts = trade_stats(trades)
        pf = portfolio(trades, fr, start_i, n, slots)
        finder.append({"stop": stop, "stats": ts, "portfolio": {kk: v for kk, v in pf.items() if kk != "equity"}})
        if stop["type"] == chosen.get("type") and float(stop.get("value", 0) or 0) == float(chosen.get("value", 0) or 0):
            main = (stop, trades, pf)
    if main is None:
        trades = run_trades(alerts, fr, bench, chosen, hold)
        main = (chosen, trades, portfolio(trades, fr, start_i, n, slots))
    ranked_ret = sorted((f for f in finder if f["stats"].get("n")), key=lambda f: -(f["stats"]["avg"] or -1e9))
    ranked_risk = sorted((f for f in finder if f["portfolio"].get("calmar") is not None),
                         key=lambda f: -f["portfolio"]["calmar"])
    ranked_cagr = sorted((f for f in finder if f["portfolio"].get("cagr") is not None),
                         key=lambda f: -f["portfolio"]["cagr"])

    stop, trades, pf = main
    # equity curves, weekly samples to keep the page light
    step = 5
    idxs = list(range(0, len(pf["equity"]), step))
    if pf["equity"] and idxs[-1] != len(pf["equity"]) - 1:
        idxs.append(len(pf["equity"]) - 1)
    curves = {"t": [str(cal[start_i + x]) for x in idxs], "Strategy": [_r(pf["equity"][x], 0) for x in idxs]}
    benches = {}
    for b, name in BENCHES:
        if b in bench:
            bh = buy_hold(bench[b], start_i)
            if bh:
                benches[b] = {kk: v for kk, v in bh.items() if kk != "equity"}
                benches[b]["name"] = name
                curves[b] = [_r(bh["equity"][x], 0) if x < len(bh["equity"]) else None for x in idxs]

    # by year
    years = {}
    for t in trades:
        y = str(cal[t["a"]["i"]])[:4]
        years.setdefault(y, []).append(t)
    by_year = [{"year": y, **trade_stats(v)} for y, v in sorted(years.items())]
    by_line = {ln: trade_stats([t for t in trades if t["a"]["line"] == ln]) for ln in ("fast", "slow", "both")}

    # alert list grouped by day (newest first)
    days = {}
    for t in trades:
        a = t["a"]
        k = a["i"]
        row = {"ticker": a["ticker"], "line": a["line"], "entry": _r(a["entry"]), "mcap_b": a["mcap"],
               "ret": _r(t["ret"]), "days": t["days"], "reason": t["reason"], "exit_date": str(cal[t["exit_i"]]),
               "vs_SPY": _r(t["ret"] - t["bench"]["SPY"]) if t["bench"].get("SPY") is not None else None}
        for hd in (21, 63, 252):
            kk = k + hd
            row[f"r{hd}"] = _r((fr["c"][kk, a["j"]] / a["entry"] - 1) * 100) if kk < n and not np.isnan(fr["c"][kk, a["j"]]) else None
        days.setdefault(str(cal[k]), []).append(row)
    alert_days = [{"date": d, "alerts": v} for d, v in sorted(days.items(), reverse=True)]

    return {
        "params": p, "info": info, "universe": len(tickers), "alerts_total": len(alerts),
        "alert_days": alert_days[:400], "alert_days_total": len(alert_days),
        "horizons": hz, "stop": stop, "stats": trade_stats(trades),
        "portfolio": {kk: v for kk, v in pf.items() if kk != "equity"}, "benchmarks": benches, "curves": curves,
        "by_year": by_year, "by_line": by_line, "finder": finder,
        "best": {"return": ranked_ret[0]["stop"] if ranked_ret else None,
                 "risk": ranked_risk[0]["stop"] if ranked_risk else None,
                 "cagr": ranked_cagr[0]["stop"] if ranked_cagr else None},
        "dataset_built": ds["built"], "fails": ds.get("fails", [])[:10],
        "finished": datetime.now().isoformat(timespec="seconds"),
    }
